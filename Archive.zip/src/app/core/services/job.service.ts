import { Injectable } from '@angular/core';
import { Job } from '../models/job.module';
import { HttpClient } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root',
})
export class JobService {

    api = 'http://localhost:3000/jobs';

    constructor(
      private http: HttpClient,
      private authService: AuthService,
    ){}

    getJobs(): Observable<Job[]> {
        const userId = this.authService.getCurrentUserId();

        if (!userId) {
          return of([]);
        }

        return this.http.get<Job[]>(`${this.api}?userId=${encodeURIComponent(userId)}`);
    }
    addJob(job: Job): Observable<Job> {
      const userId = this.authService.getCurrentUserId();

      if (!userId) {
        return throwError(() => new Error('No logged in user.'));
      }

      return this.http.post<Job>(this.api, {
        ...job,
        userId,
      });
  
    }

    updateJob(id: number, job: Job) {
      const userId = this.authService.getCurrentUserId();

      if (!userId) {
        return throwError(() => new Error('No logged in user.'));
      }

      return this.http.put<Job>(`${this.api}/${id}`, {
        ...job,
        userId,
      });
    }
    
    deleteJob(id: number) {
      return this.http.delete<void>(`${this.api}/${id}`);
    }
  
}
