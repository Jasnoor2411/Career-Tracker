import { HttpClient } from '@angular/common/http';
import { Injectable, signal } from '@angular/core';
import { map, Observable, switchMap, tap } from 'rxjs';
import { ActiveUser, User } from '../models/user.model';

const ACTIVE_USER_KEY = 'careerTrack.activeUser';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private readonly usersUrl = 'http://localhost:3000/users';
  private readonly activeUserSignal = signal<ActiveUser | null>(this.readStoredUser());

  readonly activeUser = this.activeUserSignal.asReadonly();

  constructor(private http: HttpClient) {}

  login(email: string, password: string): Observable<ActiveUser | null> {
    const normalizedEmail = email.trim().toLowerCase();

    return this.http.get<User[]>(this.usersUrl).pipe(
      map((users) =>
        users.find(
          (user) =>
            user.email.toLowerCase() === normalizedEmail &&
            user.password === password
        ) ?? null
      ),
      map((user) => (user ? this.toActiveUser(user) : null)),
      tap((user) => {
        if (user) {
          this.setActiveUser(user);
        }
      })
    );
  }

  signup(name: string, email: string, password: string): Observable<ActiveUser | null> {
    const normalizedEmail = email.trim().toLowerCase();

    return this.http.get<User[]>(this.usersUrl).pipe(
      switchMap((users) => {
        const existingUser = users.some(
          (user) => user.email.toLowerCase() === normalizedEmail
        );

        if (existingUser) {
          return [null];
        }

        const user: User = {
          id: `user-${Date.now()}`,
          name: name.trim(),
          email: normalizedEmail,
          password,
        };

        return this.http.post<User>(this.usersUrl, user).pipe(
          map((createdUser) => this.toActiveUser(createdUser))
        );
      }),
      tap((user) => {
        if (user) {
          this.setActiveUser(user);
        }
      })
    );
  }

  logout(): void {
    localStorage.removeItem(ACTIVE_USER_KEY);
    this.activeUserSignal.set(null);
  }

  isLoggedIn(): boolean {
    return Boolean(this.activeUserSignal());
  }

  getCurrentUserId(): string | null {
    return this.activeUserSignal()?.id ?? null;
  }

  private setActiveUser(user: ActiveUser): void {
    localStorage.setItem(ACTIVE_USER_KEY, JSON.stringify(user));
    this.activeUserSignal.set(user);
  }

  private readStoredUser(): ActiveUser | null {
    const stored = localStorage.getItem(ACTIVE_USER_KEY);

    if (!stored) {
      return null;
    }

    try {
      return JSON.parse(stored) as ActiveUser;
    } catch {
      localStorage.removeItem(ACTIVE_USER_KEY);
      return null;
    }
  }

  private toActiveUser(user: User): ActiveUser {
    return {
      id: user.id,
      name: user.name,
      email: user.email,
    };
  }
}
